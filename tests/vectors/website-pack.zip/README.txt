MIVIA EVIDENCE PACK

Record 44b00c6de99f6516: "Song" by Tester
Certificate: http://localhost:8788/c/44b00c6de99f6516
Pack generated: 2026-10-16T00:12:34.484Z

What this proves, and what it does not
This pack shows what was registered with Mivia, by which account, and that the
record existed no later than the Bitcoin block in its timestamp. It does not prove
who wrote the music or who owns it. That is for contracts, registries and courts.

What is inside
1-registration/   Fixed when the recording was registered. Never changes.
  manifest.json            the registration record, exactly as signed
  manifest.sig             Mivia's Ed25519 signature over manifest.json
  timestamp.ots            OpenTimestamps proof for BLAKE3(manifest.json)
  bitcoin.json             the Bitcoin block and transaction, once anchored
  watermark-payload.hex    the payload embedded in the audio (web registrations)
  fingerprint.chromaprint  the registered acoustic fingerprint
2-statement/      Mivia's signed account of the record on the date above:
                  assurance level, warnings, creation history, lineage, scan dates.
                  A later pack may say something different; this one stays dated.
3-keys/           Mivia's public keys. Compare them with
                  http://localhost:8788/.well-known/mivia-keys.json and the verifier's repository.
summary.html      A printable summary.

How to check it
Use the open-source verifier (https://github.com/MiviaCo/mivia-verify):
    pip install mivia-verify
    mivia-verify this-pack.zip --audio the-recording.wav
It checks every step without relying on Mivia. To check this pack online instead,
contact Mivia (support@mivia.co) for access.

If the audio file is the exact file that was registered, its SHA-256
(shasum -a 256 <file>) equals extensions.audio.file_sha256 in manifest.json.
This field exists only for recordings registered from October 2026.
